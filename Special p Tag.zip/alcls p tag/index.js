function rainbow(){
    let style = document.createElement("style");
    style.innerHTML = 'p {\n      background: linear-gradient(to right, red, orange, yellow, green, blue, indigo, violet);\n      -webkit-background-clip: text;\n      -webkit-text-fill-color: transparent;\n      animation: rainbow 5s linear infinite;\n    }\n    \n    @keyframes rainbow {\n      0% {\n        background-position: 0% 50%;\n      }\n      100% {\n        background-position: 100% 50%;\n      }\n    }';
    document.body.appendChild(style);
    console.log("적용됨");
}

rainbow();
